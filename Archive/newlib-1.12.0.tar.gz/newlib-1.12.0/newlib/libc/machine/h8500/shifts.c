

int __ashrhi3(int a,int b)
{
  return a>>b;
}

int __ashlhi3(int a,int b)
{
  return a<<b;
}

unsigned __lshlhi3(unsigned int a,int b)
{
  return a<<b;
}

unsigned __lshrhi3(unsigned int a,int b)
{
  return a>>b;
}




long __ashrsi3(long a, int b)
{
  return a>>b;
}

long __ashlsi3(long a,int b)
{
  return a<<b;
}

unsigned __lshlsi3(unsigned long a,int b)
{
  return a<<b;
}

unsigned __lshrsi3(unsigned long a,int b)
{
  return a>>b;
}

